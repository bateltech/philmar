# philmar
Artist website developed with Next.js

## To Discuss
### Discography
- Should we keep the descriptions as they are ?
- Should we change how each album is displayed ?
- Should we include just the year or the full date of an album ?
- https://www.be-shop.fr/